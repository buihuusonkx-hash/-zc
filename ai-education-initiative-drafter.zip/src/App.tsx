/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useRef } from 'react';
import { GoogleGenAI } from "@google/genai";
import { 
  BookOpen, 
  Send, 
  Loader2, 
  Download, 
  Copy, 
  Check, 
  Sparkles,
  FileText,
  AlertCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import ReactMarkdown from 'react-markdown';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

// Utility for tailwind classes
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export default function App() {
  const [initiativeName, setInitiativeName] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedContent, setGeneratedContent] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const resultRef = useRef<HTMLDivElement>(null);

  const handleGenerate = async () => {
    if (!initiativeName.trim()) return;

    setIsGenerating(true);
    setError(null);
    setGeneratedContent('');

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const model = "gemini-3-flash-preview";

      const prompt = `
        Bạn là một chuyên gia giáo dục xuất sắc tại Việt Nam. Hãy viết một bản thảo chi tiết và mang tính học thuật cao cho "Bản mô tả sáng kiến" với tên đề tài: "${initiativeName}".
        Lĩnh vực trọng tâm: Ứng dụng Trí tuệ Nhân tạo (AI) và Chuyển đổi số trong phương pháp dạy học.
        
        Vui lòng viết thật dài, chi tiết, logic và CHẮC CHẮN PHẢI TUÂN THỦ đúng cấu trúc sau đây:
        
        I. THÔNG TIN CHUNG VỀ SÁNG KIẾN
        - Tên sáng kiến: ${initiativeName}
        - Lĩnh vực áp dụng: Kỹ thuật - Ứng dụng CNTT và Chuyển đổi số giáo dục.
        
        II. Mô tả giải pháp đã biết
        - Mô tả thực trạng giải pháp đang triển khai tại Việt Nam và cơ quan.
        - Nêu ưu điểm của phương pháp cũ.
        - Phân tích sâu sắc những tồn tại, nhược điểm, từ đó đưa ra lý do cần giải pháp mới.
        
        III. Nội dung giải pháp đề nghị công nhận sáng kiến
        - III.1. Nội dung giải pháp: Nêu chi tiết các bước, các nội dung thực hiện (ít nhất 4 bước cụ thể về việc áp dụng AI/nền tảng số vào giáo án, giảng dạy, kiểm tra đánh giá).
        - III.2. Tính mới, tính sáng tạo: Nêu rõ những điểm cải tiến, ưu việt chưa từng có.
        - III.3. Phạm vi ảnh hưởng, khả năng áp dụng: Chứng minh tính khả thi để nhân rộng ra các trường khác.
        - III.4. Hiệu quả, lợi ích thu được: Lập bảng so sánh tình trạng "Trước" và "Sau" khi áp dụng.
      `;

      const response = await ai.models.generateContent({
        model: model,
        contents: prompt,
      });

      const text = response.text;
      if (text) {
        setGeneratedContent(text);
        // Scroll to result after a short delay to allow rendering
        setTimeout(() => {
          resultRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }, 100);
      } else {
        throw new Error("Không nhận được phản hồi từ AI.");
      }
    } catch (err: any) {
      console.error("Generation error:", err);
      setError(err.message || "Có lỗi xảy ra trong quá trình tạo bản thảo.");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(generatedContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const element = document.createElement("a");
    const file = new Blob([generatedContent], {type: 'text/plain'});
    element.href = URL.createObjectURL(file);
    element.download = "Ban_Thao_Sang_Kien.txt";
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="min-h-screen bg-[#F5F5F0] text-[#1A1A1A] font-serif selection:bg-[#5A5A40] selection:text-white">
      {/* Header */}
      <header className="border-b border-[#1A1A1A]/10 bg-white/50 backdrop-blur-md sticky top-0 z-10">
        <div className="max-w-4xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-[#5A5A40] rounded-full flex items-center justify-center text-white">
              <BookOpen size={20} />
            </div>
            <div>
              <h1 className="font-bold text-xl tracking-tight">AI Initiative</h1>
              <p className="text-[10px] uppercase tracking-widest opacity-60 font-sans font-semibold">Educational Drafting Tool</p>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-6 py-12">
        {/* Hero Section */}
        <section className="mb-16 text-center">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-5xl font-light mb-6 leading-tight"
          >
            Nâng tầm <span className="italic">sáng kiến giáo dục</span> <br /> 
            với sức mạnh của AI.
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-lg text-[#1A1A1A]/60 max-w-2xl mx-auto font-sans"
          >
            Công cụ hỗ trợ giáo viên xây dựng bản thảo sáng kiến chi tiết, 
            đúng cấu trúc chuẩn và mang tính học thuật cao.
          </motion.p>
        </section>

        {/* Input Section */}
        <section className="bg-white rounded-[32px] p-8 shadow-sm border border-[#1A1A1A]/5 mb-12">
          <div className="space-y-6">
            <div>
              <label htmlFor="initiative" className="block text-xs uppercase tracking-widest font-sans font-bold mb-3 opacity-50">
                Tên sáng kiến của bạn
              </label>
              <div className="relative">
                <textarea
                  id="initiative"
                  rows={3}
                  className="w-full bg-[#F5F5F0]/50 border border-[#1A1A1A]/10 rounded-2xl p-4 focus:outline-none focus:ring-2 focus:ring-[#5A5A40]/20 focus:border-[#5A5A40] transition-all text-lg resize-none"
                  placeholder="Ví dụ: Ứng dụng AI trong việc cá nhân hóa lộ trình học tập cho học sinh tiểu học..."
                  value={initiativeName}
                  onChange={(e) => setInitiativeName(e.target.value)}
                />
                <div className="absolute bottom-4 right-4 text-[10px] font-sans opacity-40">
                  {initiativeName.length} ký tự
                </div>
              </div>
            </div>

            <button
              onClick={handleGenerate}
              disabled={isGenerating || !initiativeName.trim()}
              className={cn(
                "w-full py-4 rounded-full flex items-center justify-center gap-2 transition-all font-sans font-bold tracking-wide",
                isGenerating || !initiativeName.trim() 
                  ? "bg-[#1A1A1A]/10 text-[#1A1A1A]/30 cursor-not-allowed" 
                  : "bg-[#5A5A40] text-white hover:bg-[#4A4A30] active:scale-[0.98] shadow-lg shadow-[#5A5A40]/20"
              )}
            >
              {isGenerating ? (
                <>
                  <Loader2 className="animate-spin" size={20} />
                  <span>ĐANG PHÂN TÍCH VÀ SOẠN THẢO...</span>
                </>
              ) : (
                <>
                  <Sparkles size={20} />
                  <span>BẮT ĐẦU TẠO BẢN THẢO</span>
                </>
              )}
            </button>
          </div>

          {error && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              className="mt-6 p-4 bg-red-50 border border-red-100 rounded-2xl flex items-start gap-3 text-red-600 font-sans text-sm"
            >
              <AlertCircle size={18} className="shrink-0 mt-0.5" />
              <p>{error}</p>
            </motion.div>
          )}
        </section>

        {/* Result Section */}
        <AnimatePresence>
          {generatedContent && (
            <motion.section 
              ref={resultRef}
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              <div className="flex items-center justify-between px-2">
                <div className="flex items-center gap-2 text-[#5A5A40]">
                  <FileText size={20} />
                  <span className="font-sans font-bold text-sm uppercase tracking-widest">Kết quả bản thảo</span>
                </div>
                <div className="flex items-center gap-2">
                  <button 
                    onClick={handleCopy}
                    className="p-2 hover:bg-[#5A5A40]/10 rounded-full transition-colors text-[#5A5A40]"
                    title="Sao chép"
                  >
                    {copied ? <Check size={18} /> : <Copy size={18} />}
                  </button>
                  <button 
                    onClick={handleDownload}
                    className="p-2 hover:bg-[#5A5A40]/10 rounded-full transition-colors text-[#5A5A40]"
                    title="Tải về .txt"
                  >
                    <Download size={18} />
                  </button>
                </div>
              </div>

              <div className="bg-white rounded-[32px] p-8 md:p-12 shadow-xl border border-[#1A1A1A]/5 prose prose-stone max-w-none prose-headings:font-serif prose-headings:font-bold prose-p:leading-relaxed prose-li:leading-relaxed">
                <ReactMarkdown>{generatedContent}</ReactMarkdown>
              </div>

              <div className="text-center pt-8 pb-12">
                <p className="text-sm text-[#1A1A1A]/40 font-sans italic">
                  Lưu ý: Đây là bản thảo do AI tạo ra. Thầy/Cô vui lòng bổ sung số liệu thực tế <br /> 
                  và điều chỉnh cho phù hợp với đặc thù của đơn vị công tác.
                </p>
              </div>
            </motion.section>
          )}
        </AnimatePresence>

        {/* Loading State Placeholder */}
        {isGenerating && !generatedContent && (
          <div className="space-y-6 animate-pulse">
            <div className="h-4 w-32 bg-[#1A1A1A]/5 rounded-full mx-auto" />
            <div className="bg-white/50 rounded-[32px] h-[600px] border border-[#1A1A1A]/5" />
          </div>
        )}
      </main>

      <footer className="border-t border-[#1A1A1A]/5 py-12 bg-white/30">
        <div className="max-w-4xl mx-auto px-6 text-center space-y-4">
          <div className="flex justify-center gap-6 opacity-30">
            <BookOpen size={24} />
            <Sparkles size={24} />
            <FileText size={24} />
          </div>
          <p className="text-[10px] uppercase tracking-[0.2em] font-sans font-bold opacity-40">
            © 2026 AI Education Initiative Assistant • Powered by Gemini
          </p>
        </div>
      </footer>
    </div>
  );
}
