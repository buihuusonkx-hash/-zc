/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { 
  LayoutDashboard, 
  BookOpen, 
  Grid3X3, 
  Database, 
  FileText, 
  Settings, 
  Plus, 
  Search, 
  Trash2, 
  Edit, 
  ChevronRight, 
  BrainCircuit,
  Save,
  Download,
  Upload,
  CheckCircle2,
  AlertCircle,
  Clock,
  Menu,
  X,
  Eye,
  Sparkles,
  Calculator
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import Swal from 'sweetalert2';
import { cn } from './lib/utils';
import { storage } from './storage';
import { 
  AppData, 
  Subject, 
  Topic, 
  Question, 
  QuestionType, 
  CognitiveLevel, 
  ExamMatrix, 
  Exam 
} from './types';
import { callGeminiAI, MODELS } from './services/geminiService';

// --- Components ---

const SidebarItem = ({ icon: Icon, label, active, onClick }: { icon: any, label: string, active: boolean, onClick: () => void }) => (
  <button
    onClick={onClick}
    className={cn(
      "flex items-center gap-3 w-full px-4 py-3 rounded-xl transition-all duration-200 group",
      active 
        ? "bg-primary text-white shadow-md shadow-primary/20" 
        : "text-slate-500 hover:bg-slate-100 hover:text-primary"
    )}
  >
    <Icon size={20} className={cn(active ? "text-white" : "group-hover:scale-110 transition-transform")} />
    <span className="font-medium">{label}</span>
  </button>
);

const Card = ({ children, className, title, subtitle, action }: { children: React.ReactNode, className?: string, title?: string, subtitle?: string, action?: React.ReactNode }) => (
  <div className={cn("glass-card rounded-2xl p-6", className)}>
    {(title || action) && (
      <div className="flex items-center justify-between mb-6">
        <div>
          {title && <h3 className="text-lg font-bold text-slate-800">{title}</h3>}
          {subtitle && <p className="text-sm text-slate-500">{subtitle}</p>}
        </div>
        {action}
      </div>
    )}
    {children}
  </div>
);

const Badge = ({ children, variant = 'default' }: { children: React.ReactNode, variant?: 'default' | 'success' | 'warning' | 'error' | 'info' }) => {
  const variants = {
    default: "bg-slate-100 text-slate-600",
    success: "bg-emerald-100 text-emerald-600",
    warning: "bg-amber-100 text-amber-600",
    error: "bg-rose-100 text-rose-600",
    info: "bg-blue-100 text-blue-600"
  };
  return (
    <span className={cn("px-2.5 py-0.5 rounded-full text-xs font-semibold", variants[variant])}>
      {children}
    </span>
  );
};

// --- Main App ---

export default function App() {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'curriculum' | 'matrix' | 'bank' | 'exam' | 'settings'>('dashboard');
  const [data, setData] = useState<AppData>(storage.get());
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isLoading, setIsLoading] = useState(false);

  // Sync with storage
  useEffect(() => {
    storage.set(data);
  }, [data]);

  const handleSaveSettings = (newSettings: AppData['settings']) => {
    setData(prev => ({ ...prev, settings: newSettings }));
    Swal.fire({
      title: 'Đã lưu!',
      text: 'Cài đặt của bạn đã được cập nhật.',
      icon: 'success',
      timer: 1500,
      showConfirmButton: false
    });
  };

  const exportData = () => {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `edumatrix-backup-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
  };

  const importData = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const imported = JSON.parse(event.target?.result as string);
        setData(imported);
        Swal.fire('Thành công', 'Dữ liệu đã được khôi phục', 'success');
      } catch (err) {
        Swal.fire('Lỗi', 'File không hợp lệ', 'error');
      }
    };
    reader.readAsText(file);
  };

  // --- Views ---

  const DashboardView = () => (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Môn học', value: data.subjects.length, icon: BookOpen, color: 'text-blue-500', bg: 'bg-blue-50' },
          { label: 'Câu hỏi', value: data.questions.length, icon: Database, color: 'text-emerald-500', bg: 'bg-emerald-50' },
          { label: 'Ma trận', value: data.matrices.length, icon: Grid3X3, color: 'text-amber-500', bg: 'bg-amber-50' },
          { label: 'Đề thi', value: data.exams.length, icon: FileText, color: 'text-rose-500', bg: 'bg-rose-50' },
        ].map((stat, i) => (
          <Card key={i} className="flex items-center gap-4 p-4">
            <div className={cn("p-3 rounded-xl", stat.bg)}>
              <stat.icon className={stat.color} size={24} />
            </div>
            <div>
              <p className="text-sm text-slate-500">{stat.label}</p>
              <p className="text-2xl font-bold text-slate-800">{stat.value}</p>
            </div>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card title="Môn học gần đây" className="lg:col-span-2">
          <div className="space-y-4">
            {data.subjects.length === 0 ? (
              <div className="text-center py-12 text-slate-400">Chưa có môn học nào</div>
            ) : (
              data.subjects.map(subject => (
                <div key={subject.id} className="flex items-center justify-between p-4 rounded-xl border border-slate-100 hover:border-primary/30 hover:bg-primary/5 transition-all cursor-pointer group">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-slate-100 flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-white transition-colors">
                      <BookOpen size={24} />
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-800">{subject.name}</h4>
                      <p className="text-sm text-slate-500">{subject.topics.length} chủ đề • {data.questions.filter(q => q.subjectId === subject.id).length} câu hỏi</p>
                    </div>
                  </div>
                  <ChevronRight className="text-slate-300 group-hover:text-primary group-hover:translate-x-1 transition-all" />
                </div>
              ))
            )}
          </div>
        </Card>

        <Card title="AI Tutor" subtitle="Trợ lý biên soạn đề thi">
          <div className="space-y-4">
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 text-sm text-slate-600 italic">
              "Chào bạn! Tôi có thể giúp bạn tạo ma trận đề thi hoặc sinh câu hỏi trắc nghiệm từ nội dung bài học. Bạn muốn bắt đầu từ đâu?"
            </div>
            <div className="grid grid-cols-1 gap-2">
              <button onClick={() => setActiveTab('matrix')} className="flex items-center gap-2 px-4 py-2 rounded-xl bg-primary/10 text-primary text-sm font-medium hover:bg-primary/20 transition-colors">
                <Sparkles size={16} /> Tạo ma trận tự động
              </button>
              <button onClick={() => setActiveTab('bank')} className="flex items-center gap-2 px-4 py-2 rounded-xl bg-secondary/10 text-secondary text-sm font-medium hover:bg-secondary/20 transition-colors">
                <BrainCircuit size={16} /> Sinh câu hỏi từ AI
              </button>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );

  const CurriculumView = () => {
    const [isAdding, setIsAdding] = useState(false);
    const [newSubject, setNewSubject] = useState({ name: '' });

    const addSubject = () => {
      if (!newSubject.name) return;
      const id = Math.random().toString(36).substr(2, 9);
      setData(prev => ({
        ...prev,
        subjects: [...prev.subjects, { id, name: newSubject.name, icon: 'BookOpen', topics: [] }]
      }));
      setNewSubject({ name: '' });
      setIsAdding(false);
    };

    return (
      <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold text-slate-800">Cấu trúc chương trình</h2>
          <button 
            onClick={() => setIsAdding(true)}
            className="flex items-center gap-2 px-4 py-2 rounded-xl gradient-bg text-white font-bold shadow-lg shadow-primary/20 hover:scale-105 transition-transform"
          >
            <Plus size={20} /> Thêm môn học
          </button>
        </div>

        {isAdding && (
          <Card className="border-2 border-primary/30">
            <div className="flex gap-4">
              <input 
                autoFocus
                type="text" 
                placeholder="Tên môn học (VD: Toán học 10)" 
                className="flex-1 px-4 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-primary/50"
                value={newSubject.name}
                onChange={e => setNewSubject({ name: e.target.value })}
                onKeyDown={e => e.key === 'Enter' && addSubject()}
              />
              <button onClick={addSubject} className="px-6 py-2 rounded-xl bg-primary text-white font-bold">Lưu</button>
              <button onClick={() => setIsAdding(false)} className="px-4 py-2 rounded-xl bg-slate-100 text-slate-500">Hủy</button>
            </div>
          </Card>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {data.subjects.map(subject => (
            <Card 
              key={subject.id} 
              title={subject.name} 
              action={
                <button onClick={() => {
                  setData(prev => ({ ...prev, subjects: prev.subjects.filter(s => s.id !== subject.id) }));
                }} className="text-slate-300 hover:text-rose-500 transition-colors">
                  <Trash2 size={18} />
                </button>
              }
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between text-sm font-bold text-slate-500 border-b pb-2">
                  <span>Chủ đề / Bài học</span>
                  <span>Số tiết</span>
                </div>
                {subject.topics.map(topic => (
                  <div key={topic.id} className="flex items-center justify-between py-2 group">
                    <div className="flex-1">
                      <p className="font-medium text-slate-700">{topic.name}</p>
                      <div className="flex gap-1 mt-1">
                        {topic.outcomes.map((o, idx) => <Badge key={idx}>{o}</Badge>)}
                      </div>
                    </div>
                    <span className="px-3 py-1 rounded-lg bg-slate-100 text-slate-600 font-mono text-sm">{topic.periods}</span>
                  </div>
                ))}
                <button 
                  onClick={async () => {
                    const { value: formValues } = await Swal.fire({
                      title: 'Thêm chủ đề mới',
                      html:
                        '<input id="swal-input1" class="swal2-input" placeholder="Tên chủ đề">' +
                        '<input id="swal-input2" type="number" class="swal2-input" placeholder="Số tiết">',
                      focusConfirm: false,
                      preConfirm: () => {
                        return [
                          (document.getElementById('swal-input1') as HTMLInputElement).value,
                          (document.getElementById('swal-input2') as HTMLInputElement).value
                        ]
                      }
                    });
                    if (formValues && formValues[0]) {
                      const newTopic: Topic = {
                        id: Math.random().toString(36).substr(2, 9),
                        name: formValues[0],
                        periods: parseInt(formValues[1]) || 1,
                        outcomes: []
                      };
                      setData(prev => ({
                        ...prev,
                        subjects: prev.subjects.map(s => s.id === subject.id ? { ...s, topics: [...s.topics, newTopic] } : s)
                      }));
                    }
                  }}
                  className="w-full py-2 rounded-xl border-2 border-dashed border-slate-200 text-slate-400 hover:border-primary/50 hover:text-primary transition-all flex items-center justify-center gap-2"
                >
                  <Plus size={16} /> Thêm chủ đề
                </button>
              </div>
            </Card>
          ))}
        </div>
      </div>
    );
  };

  const MatrixView = () => {
    const [selectedSubjectId, setSelectedSubjectId] = useState(data.subjects[0]?.id || '');
    const subject = data.subjects.find(s => s.id === selectedSubjectId);

    const generateMatrixAI = async () => {
      if (!data.settings.apiKey) {
        Swal.fire('Thiếu API Key', 'Vui lòng cấu hình API Key trong phần Cài đặt', 'warning');
        return;
      }
      if (!subject) return;

      setIsLoading(true);
      try {
        const prompt = `Hãy tạo một ma trận đề thi chuẩn cho môn ${subject.name} gồm các chủ đề: ${subject.topics.map(t => t.name).join(', ')}. 
        Tổng 40 câu trắc nghiệm, 10 điểm. Phân bổ theo 4 mức độ: Nhận biết (40%), Thông hiểu (30%), Vận dụng (20%), Vận dụng cao (10%).
        Trả về JSON mảng các cell: { topicId: string, level: string, count: number }. 
        Lưu ý topicId phải khớp với: ${JSON.stringify(subject.topics.map(t => ({ id: t.id, name: t.name })))}`;
        
        const result = await callGeminiAI(prompt, data.settings.apiKey, data.settings.model);
        if (result) {
          // Parse JSON from AI response
          const jsonMatch = result.match(/\[[\s\S]*\]/);
          if (jsonMatch) {
            const cells = JSON.parse(jsonMatch[0]);
            const newMatrix: ExamMatrix = {
              id: Math.random().toString(36).substr(2, 9),
              subjectId: subject.id,
              name: `Ma trận tự động - ${subject.name}`,
              cells: cells.map((c: any) => ({ ...c, type: QuestionType.MULTIPLE_CHOICE })),
              totalScore: 10,
              duration: 90
            };
            setData(prev => ({ ...prev, matrices: [...prev.matrices, newMatrix] }));
            Swal.fire('Thành công', 'Ma trận đã được khởi tạo tự động', 'success');
          }
        }
      } catch (err) {
        Swal.fire('Lỗi', 'Không thể sinh ma trận từ AI', 'error');
      } finally {
        setIsLoading(false);
      }
    };

    return (
      <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold text-slate-800">Ma trận & Đặc tả</h2>
          <div className="flex gap-2">
            <select 
              className="px-4 py-2 rounded-xl border border-slate-200 bg-white"
              value={selectedSubjectId}
              onChange={e => setSelectedSubjectId(e.target.value)}
            >
              {data.subjects.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
            <button 
              onClick={generateMatrixAI}
              disabled={isLoading}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-secondary text-white font-bold shadow-lg shadow-secondary/20 hover:scale-105 transition-transform disabled:opacity-50"
            >
              {isLoading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Sparkles size={20} />}
              AI Sinh ma trận
            </button>
          </div>
        </div>

        {data.matrices.filter(m => m.subjectId === selectedSubjectId).map(matrix => (
          <Card key={matrix.id} title={matrix.name} subtitle={`Thời gian: ${matrix.duration} phút • Thang điểm: ${matrix.totalScore}`}>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-slate-50 text-slate-500">
                    <th className="p-3 text-left rounded-tl-xl">Chủ đề</th>
                    <th className="p-3 text-center">Nhận biết</th>
                    <th className="p-3 text-center">Thông hiểu</th>
                    <th className="p-3 text-center">Vận dụng</th>
                    <th className="p-3 text-center">Vận dụng cao</th>
                    <th className="p-3 text-center rounded-tr-xl">Tổng</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {subject?.topics.map(topic => {
                    const getCount = (level: CognitiveLevel) => matrix.cells.find(c => c.topicId === topic.id && c.level === level)?.count || 0;
                    const rowTotal = getCount(CognitiveLevel.RECOGNIZE) + getCount(CognitiveLevel.UNDERSTAND) + getCount(CognitiveLevel.APPLY) + getCount(CognitiveLevel.HIGH_APPLY);
                    return (
                      <tr key={topic.id} className="hover:bg-slate-50/50">
                        <td className="p-3 font-medium text-slate-700">{topic.name}</td>
                        <td className="p-3 text-center">{getCount(CognitiveLevel.RECOGNIZE)}</td>
                        <td className="p-3 text-center">{getCount(CognitiveLevel.UNDERSTAND)}</td>
                        <td className="p-3 text-center">{getCount(CognitiveLevel.APPLY)}</td>
                        <td className="p-3 text-center">{getCount(CognitiveLevel.HIGH_APPLY)}</td>
                        <td className="p-3 text-center font-bold text-primary">{rowTotal}</td>
                      </tr>
                    );
                  })}
                </tbody>
                <tfoot>
                  <tr className="bg-primary/5 font-bold text-primary">
                    <td className="p-3">Tổng cộng</td>
                    {[CognitiveLevel.RECOGNIZE, CognitiveLevel.UNDERSTAND, CognitiveLevel.APPLY, CognitiveLevel.HIGH_APPLY].map(lvl => (
                      <td key={lvl} className="p-3 text-center">
                        {matrix.cells.filter(c => c.level === lvl).reduce((sum, c) => sum + c.count, 0)}
                      </td>
                    ))}
                    <td className="p-3 text-center text-lg">
                      {matrix.cells.reduce((sum, c) => sum + c.count, 0)}
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </Card>
        ))}
      </div>
    );
  };

  const QuestionBankView = () => {
    const [filterSubject, setFilterSubject] = useState('');
    const [filterLevel, setFilterLevel] = useState('');
    const [filterType, setFilterType] = useState('');
    const [searchQuery, setSearchQuery] = useState('');
    const [isAdding, setIsAdding] = useState(false);
    const [newQuestion, setNewQuestion] = useState<Partial<Question>>({
      type: QuestionType.MULTIPLE_CHOICE,
      level: CognitiveLevel.RECOGNIZE,
      options: ['', '', '', ''],
      correctAnswer: '',
      subjectId: '',
      topicId: '',
      content: ''
    });

    const filteredQuestions = data.questions.filter(q => {
      const matchesSubject = !filterSubject || q.subjectId === filterSubject;
      const matchesLevel = !filterLevel || q.level === filterLevel;
      const matchesType = !filterType || q.type === filterType;
      const matchesSearch = !searchQuery || q.content.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesSubject && matchesLevel && matchesType && matchesSearch;
    });

    const handleAddQuestion = () => {
      if (!newQuestion.content || !newQuestion.subjectId || !newQuestion.topicId || !newQuestion.correctAnswer) {
        Swal.fire('Lỗi', 'Vui lòng điền đầy đủ thông tin câu hỏi', 'warning');
        return;
      }

      const question: Question = {
        id: Math.random().toString(36).substr(2, 9),
        subjectId: newQuestion.subjectId!,
        topicId: newQuestion.topicId!,
        content: newQuestion.content!,
        type: newQuestion.type as QuestionType,
        level: newQuestion.level as CognitiveLevel,
        options: newQuestion.options,
        correctAnswer: newQuestion.correctAnswer as string,
        explanation: newQuestion.explanation
      };

      setData(prev => ({ ...prev, questions: [question, ...prev.questions] }));
      setIsAdding(false);
      setNewQuestion({
        type: QuestionType.MULTIPLE_CHOICE,
        level: CognitiveLevel.RECOGNIZE,
        options: ['', '', '', ''],
        correctAnswer: '',
        subjectId: '',
        topicId: '',
        content: ''
      });
      Swal.fire('Thành công', 'Đã thêm câu hỏi vào ngân hàng', 'success');
    };

    const selectedSubject = data.subjects.find(s => s.id === newQuestion.subjectId);

    return (
      <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <h2 className="text-2xl font-bold text-slate-800">Ngân hàng câu hỏi</h2>
          <div className="flex gap-2">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input 
                type="text" 
                placeholder="Tìm kiếm câu hỏi..." 
                className="pl-10 pr-4 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-primary/50 outline-none w-full md:w-64"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
              />
            </div>
            <select 
              className="px-4 py-2 rounded-xl border border-slate-200 bg-white"
              value={filterSubject}
              onChange={e => setFilterSubject(e.target.value)}
            >
              <option value="">Tất cả môn học</option>
              {data.subjects.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
            <select 
              className="px-4 py-2 rounded-xl border border-slate-200 bg-white"
              value={filterLevel}
              onChange={e => setFilterLevel(e.target.value)}
            >
              <option value="">Tất cả mức độ</option>
              <option value={CognitiveLevel.RECOGNIZE}>Nhận biết</option>
              <option value={CognitiveLevel.UNDERSTAND}>Thông hiểu</option>
              <option value={CognitiveLevel.APPLY}>Vận dụng</option>
              <option value={CognitiveLevel.HIGH_APPLY}>Vận dụng cao</option>
            </select>
            <select 
              className="px-4 py-2 rounded-xl border border-slate-200 bg-white"
              value={filterType}
              onChange={e => setFilterType(e.target.value)}
            >
              <option value="">Tất cả dạng</option>
              <option value={QuestionType.MULTIPLE_CHOICE}>Trắc nghiệm</option>
              <option value={QuestionType.TRUE_FALSE}>Đúng/Sai</option>
              <option value={QuestionType.SHORT_ANSWER}>Tự luận ngắn</option>
            </select>
            <button 
              onClick={() => setIsAdding(true)}
              className="flex items-center gap-2 px-4 py-2 rounded-xl gradient-bg text-white font-bold shadow-lg shadow-primary/20 hover:scale-105 transition-transform"
            >
              <Plus size={20} /> Thêm câu hỏi
            </button>
          </div>
        </div>

        {isAdding && (
          <Card title="Thêm câu hỏi mới" subtitle="Nhập thông tin câu hỏi">
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">Môn học</label>
                  <select 
                    className="w-full px-4 py-2 rounded-xl border border-slate-200 bg-white"
                    value={newQuestion.subjectId}
                    onChange={e => setNewQuestion({ ...newQuestion, subjectId: e.target.value, topicId: '' })}
                  >
                    <option value="">Chọn môn học</option>
                    {data.subjects.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">Chủ đề</label>
                  <select 
                    className="w-full px-4 py-2 rounded-xl border border-slate-200 bg-white"
                    value={newQuestion.topicId}
                    onChange={e => setNewQuestion({ ...newQuestion, topicId: e.target.value })}
                    disabled={!newQuestion.subjectId}
                  >
                    <option value="">Chọn chủ đề</option>
                    {selectedSubject?.topics.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">Dạng câu hỏi</label>
                  <select 
                    className="w-full px-4 py-2 rounded-xl border border-slate-200 bg-white"
                    value={newQuestion.type}
                    onChange={e => {
                      const type = e.target.value as QuestionType;
                      let options = ['', '', '', ''];
                      if (type === QuestionType.TRUE_FALSE) options = ['Đúng', 'Sai'];
                      if (type === QuestionType.SHORT_ANSWER) options = [];
                      setNewQuestion({ ...newQuestion, type, options, correctAnswer: '' });
                    }}
                  >
                    <option value={QuestionType.MULTIPLE_CHOICE}>Trắc nghiệm</option>
                    <option value={QuestionType.TRUE_FALSE}>Đúng/Sai</option>
                    <option value={QuestionType.SHORT_ANSWER}>Tự luận ngắn</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">Mức độ nhận thức</label>
                <div className="flex gap-2">
                  {[
                    { val: CognitiveLevel.RECOGNIZE, label: 'Nhận biết' },
                    { val: CognitiveLevel.UNDERSTAND, label: 'Thông hiểu' },
                    { val: CognitiveLevel.APPLY, label: 'Vận dụng' },
                    { val: CognitiveLevel.HIGH_APPLY, label: 'Vận dụng cao' }
                  ].map(lvl => (
                    <button
                      key={lvl.val}
                      onClick={() => setNewQuestion({ ...newQuestion, level: lvl.val })}
                      className={cn(
                        "px-4 py-2 rounded-xl text-sm font-medium transition-all",
                        newQuestion.level === lvl.val ? "bg-primary text-white" : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                      )}
                    >
                      {lvl.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">Nội dung câu hỏi</label>
                <textarea 
                  className="w-full px-4 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-primary/50 outline-none min-h-[100px]"
                  placeholder="Nhập nội dung câu hỏi..."
                  value={newQuestion.content}
                  onChange={e => setNewQuestion({ ...newQuestion, content: e.target.value })}
                />
              </div>

              {newQuestion.type !== QuestionType.SHORT_ANSWER && (
                <div className="space-y-3">
                  <label className="block text-sm font-bold text-slate-700">Các phương án trả lời</label>
                  {newQuestion.options?.map((opt, idx) => (
                    <div key={idx} className="flex items-center gap-3">
                      <span className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center font-bold text-slate-500">
                        {newQuestion.type === QuestionType.MULTIPLE_CHOICE ? String.fromCharCode(65 + idx) : (idx === 0 ? '✓' : '✗')}
                      </span>
                      <input 
                        type="text" 
                        className="flex-1 px-4 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-primary/50 outline-none"
                        placeholder={`Phương án ${idx + 1}`}
                        value={opt}
                        readOnly={newQuestion.type === QuestionType.TRUE_FALSE}
                        onChange={e => {
                          const newOpts = [...(newQuestion.options || [])];
                          newOpts[idx] = e.target.value;
                          setNewQuestion({ ...newQuestion, options: newOpts });
                        }}
                      />
                      <input 
                        type="radio" 
                        name="correctAnswer"
                        checked={newQuestion.correctAnswer === opt && opt !== ''}
                        onChange={() => setNewQuestion({ ...newQuestion, correctAnswer: opt })}
                        className="w-5 h-5 text-primary focus:ring-primary"
                      />
                    </div>
                  ))}
                  <p className="text-xs text-slate-400 italic">* Tích chọn nút tròn bên phải để xác định đáp án đúng</p>
                </div>
              )}

              {newQuestion.type === QuestionType.SHORT_ANSWER && (
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">Đáp án đúng (Tự luận ngắn)</label>
                  <input 
                    type="text" 
                    className="w-full px-4 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-primary/50 outline-none"
                    placeholder="Nhập đáp án chính xác..."
                    value={newQuestion.correctAnswer as string}
                    onChange={e => setNewQuestion({ ...newQuestion, correctAnswer: e.target.value })}
                  />
                </div>
              )}

              <div className="flex gap-3 pt-4">
                <button onClick={handleAddQuestion} className="flex-1 py-3 rounded-xl bg-primary text-white font-bold shadow-lg shadow-primary/20 hover:scale-[1.02] transition-all">
                  Lưu câu hỏi
                </button>
                <button onClick={() => setIsAdding(false)} className="px-6 py-3 rounded-xl bg-slate-100 text-slate-500 font-bold hover:bg-slate-200 transition-all">
                  Hủy
                </button>
              </div>
            </div>
          </Card>
        )}

        <div className="grid grid-cols-1 gap-4">
          {filteredQuestions.length === 0 ? (
            <div className="text-center py-20 bg-white rounded-2xl border-2 border-dashed border-slate-200">
              <Database className="mx-auto text-slate-300 mb-4" size={48} />
              <p className="text-slate-500">Chưa có câu hỏi nào trong ngân hàng</p>
              <button onClick={() => setIsAdding(true)} className="mt-4 px-6 py-2 rounded-xl bg-primary text-white font-bold">Thêm câu hỏi mới</button>
            </div>
          ) : (
            filteredQuestions.map(question => (
              <Card key={question.id} className="hover:shadow-xl transition-shadow">
                <div className="flex justify-between items-start mb-4">
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="info">{data.subjects.find(s => s.id === question.subjectId)?.name}</Badge>
                    <Badge variant="default">
                      {
                        question.type === QuestionType.MULTIPLE_CHOICE ? 'Trắc nghiệm' :
                        question.type === QuestionType.TRUE_FALSE ? 'Đúng/Sai' : 'Tự luận ngắn'
                      }
                    </Badge>
                    <Badge variant={
                        question.level === CognitiveLevel.RECOGNIZE ? 'success' :
                        question.level === CognitiveLevel.UNDERSTAND ? 'info' :
                        question.level === CognitiveLevel.APPLY ? 'warning' : 'error'
                      }>
                        {
                          question.level === CognitiveLevel.RECOGNIZE ? 'Nhận biết' :
                          question.level === CognitiveLevel.UNDERSTAND ? 'Thông hiểu' :
                          question.level === CognitiveLevel.APPLY ? 'Vận dụng' : 'Vận dụng cao'
                        }
                    </Badge>
                  </div>
                  <div className="flex gap-2">
                    <button className="p-2 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-primary transition-colors"><Edit size={16} /></button>
                    <button 
                      onClick={() => setData(prev => ({ ...prev, questions: prev.questions.filter(q => q.id !== question.id) }))}
                      className="p-2 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-rose-500 transition-colors"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
                <p className="text-slate-800 font-medium mb-4">{question.content}</p>
                {question.options && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {question.options.map((opt, idx) => (
                      <div key={idx} className={cn(
                        "p-3 rounded-xl border text-sm",
                        opt === question.correctAnswer ? "bg-emerald-50 border-emerald-200 text-emerald-700 font-bold" : "border-slate-100 text-slate-600"
                      )}>
                        {String.fromCharCode(65 + idx)}. {opt}
                      </div>
                    ))}
                  </div>
                )}
              </Card>
            ))
          )}
        </div>
      </div>
    );
  };

  const ExamView = () => {
    const generateExam = () => {
      if (data.matrices.length === 0) {
        Swal.fire('Lỗi', 'Vui lòng tạo ma trận trước khi sinh đề thi', 'warning');
        return;
      }
      
      setIsLoading(true);
      setTimeout(() => {
        const matrix = data.matrices[0];
        const newExam: Exam = {
          id: Math.random().toString(36).substr(2, 9),
          matrixId: matrix.id,
          name: `Đề thi sinh từ ${matrix.name}`,
          questions: data.questions.slice(0, 10), // Mock: take first 10 questions
          createdAt: new Date().toISOString()
        };
        setData(prev => ({ ...prev, exams: [...prev.exams, newExam] }));
        setIsLoading(false);
        Swal.fire('Thành công', 'Đề thi đã được sinh ra dựa trên ma trận', 'success');
      }, 1500);
    };

    return (
      <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold text-slate-800">Quản lý đề thi</h2>
          <button 
            onClick={generateExam}
            disabled={isLoading}
            className="flex items-center gap-2 px-4 py-2 rounded-xl gradient-bg text-white font-bold shadow-lg shadow-primary/20 hover:scale-105 transition-transform disabled:opacity-50"
          >
            {isLoading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Sparkles size={20} />}
            Sinh đề thi tự động
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {data.exams.length === 0 ? (
            <div className="md:col-span-3 text-center py-20 bg-white rounded-2xl border-2 border-dashed border-slate-200">
              <FileText className="mx-auto text-slate-300 mb-4" size={48} />
              <p className="text-slate-500">Chưa có đề thi nào được tạo</p>
            </div>
          ) : (
            data.exams.map(exam => (
              <Card key={exam.id} title={exam.name} subtitle={new Date(exam.createdAt).toLocaleDateString('vi-VN')}>
                <div className="flex items-center gap-4 mb-6">
                  <div className="flex-1">
                    <p className="text-xs text-slate-400 uppercase font-bold tracking-wider">Số câu hỏi</p>
                    <p className="text-xl font-bold text-slate-800">{exam.questions.length}</p>
                  </div>
                  <div className="flex-1">
                    <p className="text-xs text-slate-400 uppercase font-bold tracking-wider">Trạng thái</p>
                    <Badge variant="success">Đã phê duyệt</Badge>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button className="flex-1 py-2 rounded-xl bg-slate-100 text-slate-600 font-bold hover:bg-slate-200 transition-colors flex items-center justify-center gap-2">
                    <Eye size={16} /> Xem
                  </button>
                  <button className="flex-1 py-2 rounded-xl bg-primary/10 text-primary font-bold hover:bg-primary/20 transition-colors flex items-center justify-center gap-2">
                    <Download size={16} /> Tải về
                  </button>
                </div>
              </Card>
            ))
          )}
        </div>
      </div>
    );
  };

  const SettingsView = () => {
    const [apiKey, setApiKey] = useState(data.settings.apiKey);
    const [model, setModel] = useState(data.settings.model);
    const [showKey, setShowKey] = useState(false);

    return (
      <div className="max-w-2xl mx-auto space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
        <h2 className="text-2xl font-bold text-slate-800">Cài đặt hệ thống</h2>
        
        <Card title="Cấu hình AI" subtitle="Kết nối với Google Gemini API">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-bold text-slate-700 mb-2">Gemini API Key</label>
              <div className="relative">
                <input 
                  type={showKey ? "text" : "password"} 
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-primary/50 outline-none"
                  placeholder="Nhập API Key của bạn..."
                  value={apiKey}
                  onChange={e => setApiKey(e.target.value)}
                />
                <button 
                  onClick={() => setShowKey(!showKey)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                >
                  {showKey ? <X size={18} /> : <Eye size={18} />}
                </button>
              </div>
              <p className="text-xs text-slate-400 mt-2">Lấy API Key tại <a href="https://aistudio.google.com/app/apikey" target="_blank" className="text-primary underline">Google AI Studio</a></p>
            </div>

            <div>
              <label className="block text-sm font-bold text-slate-700 mb-2">AI Model</label>
              <select 
                className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-white focus:ring-2 focus:ring-primary/50 outline-none"
                value={model}
                onChange={e => setModel(e.target.value)}
              >
                {MODELS.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
              </select>
            </div>

            <button 
              onClick={() => handleSaveSettings({ ...data.settings, apiKey, model })}
              className="w-full py-3 rounded-xl gradient-bg text-white font-bold shadow-lg shadow-primary/20 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-2"
            >
              <Save size={20} /> Lưu cấu hình
            </button>
          </div>
        </Card>

        <Card title="Dữ liệu & Bảo mật" subtitle="Quản lý sao lưu và khôi phục">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <button 
              onClick={exportData}
              className="p-4 rounded-2xl border-2 border-slate-100 hover:border-primary/30 hover:bg-primary/5 transition-all flex flex-col items-center gap-2"
            >
              <Download className="text-primary" size={24} />
              <span className="font-bold text-slate-700">Sao lưu dữ liệu</span>
              <span className="text-xs text-slate-400 text-center">Tải về file JSON chứa toàn bộ dữ liệu</span>
            </button>
            
            <label className="p-4 rounded-2xl border-2 border-slate-100 hover:border-emerald-300 hover:bg-emerald-50 transition-all flex flex-col items-center gap-2 cursor-pointer">
              <Upload className="text-emerald-500" size={24} />
              <span className="font-bold text-slate-700">Khôi phục dữ liệu</span>
              <span className="text-xs text-slate-400 text-center">Chọn file sao lưu để khôi phục</span>
              <input type="file" className="hidden" accept=".json" onChange={importData} />
            </label>
          </div>
          
          <button 
            onClick={() => {
              Swal.fire({
                title: 'Xác nhận xóa?',
                text: "Toàn bộ dữ liệu sẽ bị xóa vĩnh viễn!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#ef4444',
                cancelButtonColor: '#64748b',
                confirmButtonText: 'Xóa tất cả',
                cancelButtonText: 'Hủy'
              }).then((result) => {
                if (result.isConfirmed) {
                  storage.reset();
                  setData(storage.get());
                  Swal.fire('Đã xóa!', 'Dữ liệu đã được đặt lại.', 'success');
                }
              })
            }}
            className="w-full mt-4 py-3 rounded-xl border-2 border-rose-100 text-rose-500 font-bold hover:bg-rose-50 transition-all flex items-center justify-center gap-2"
          >
            <Trash2 size={20} /> Đặt lại ứng dụng
          </button>
        </Card>
      </div>
    );
  };

  return (
    <div className="flex min-h-screen bg-slate-50">
      {/* Sidebar */}
      <aside className={cn(
        "fixed inset-y-0 left-0 z-50 w-72 bg-white border-r border-slate-100 transition-transform duration-300 lg:relative lg:translate-x-0",
        !isSidebarOpen && "-translate-x-full"
      )}>
        <div className="flex flex-col h-full p-6">
          <div className="flex items-center gap-3 mb-10 px-2">
            <div className="w-10 h-10 rounded-xl gradient-bg flex items-center justify-center text-white shadow-lg shadow-primary/20">
              <Calculator size={24} />
            </div>
            <h1 className="text-xl font-black gradient-text tracking-tight">EduMatrix AI</h1>
          </div>

          <nav className="flex-1 space-y-2">
            <SidebarItem icon={LayoutDashboard} label="Tổng quan" active={activeTab === 'dashboard'} onClick={() => setActiveTab('dashboard')} />
            <SidebarItem icon={BookOpen} label="Chương trình" active={activeTab === 'curriculum'} onClick={() => setActiveTab('curriculum')} />
            <SidebarItem icon={Grid3X3} label="Ma trận & Đặc tả" active={activeTab === 'matrix'} onClick={() => setActiveTab('matrix')} />
            <SidebarItem icon={Database} label="Ngân hàng câu hỏi" active={activeTab === 'bank'} onClick={() => setActiveTab('bank')} />
            <SidebarItem icon={FileText} label="Đề thi" active={activeTab === 'exam'} onClick={() => setActiveTab('exam')} />
          </nav>

          <div className="pt-6 border-t border-slate-100">
            <SidebarItem icon={Settings} label="Cài đặt" active={activeTab === 'settings'} onClick={() => setActiveTab('settings')} />
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Header */}
        <header className="h-20 bg-white/80 backdrop-blur-md border-b border-slate-100 flex items-center justify-between px-6 sticky top-0 z-40">
          <div className="flex items-center gap-4">
            <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className="lg:hidden p-2 rounded-xl hover:bg-slate-100">
              {isSidebarOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
            <h2 className="text-lg font-bold text-slate-800">
              {activeTab === 'dashboard' && 'Bảng điều khiển'}
              {activeTab === 'curriculum' && 'Quản lý chương trình'}
              {activeTab === 'matrix' && 'Ma trận đề thi'}
              {activeTab === 'bank' && 'Ngân hàng câu hỏi'}
              {activeTab === 'exam' && 'Quản lý đề thi'}
              {activeTab === 'settings' && 'Cài đặt'}
            </h2>
          </div>

          <div className="flex items-center gap-4">
            {!data.settings.apiKey && (
              <button 
                onClick={() => setActiveTab('settings')}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-rose-50 text-rose-500 text-sm font-bold animate-pulse"
              >
                <AlertCircle size={16} /> Cấu hình API Key
              </button>
            )}
            <div className="flex items-center gap-3 pl-4 border-l border-slate-100">
              <div className="text-right hidden sm:block">
                <p className="text-sm font-bold text-slate-800">Giáo viên</p>
                <p className="text-xs text-slate-400">Quản trị viên</p>
              </div>
              <div className="w-10 h-10 rounded-full bg-slate-100 border-2 border-white shadow-sm flex items-center justify-center text-slate-400">
                <Settings size={20} />
              </div>
            </div>
          </div>
        </header>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-6">
          <div className="max-w-7xl mx-auto">
            {activeTab === 'dashboard' && <DashboardView />}
            {activeTab === 'curriculum' && <CurriculumView />}
            {activeTab === 'matrix' && <MatrixView />}
            {activeTab === 'bank' && <QuestionBankView />}
            {activeTab === 'exam' && <ExamView />}
            {activeTab === 'settings' && <SettingsView />}
          </div>
        </div>
      </main>

      {/* Mobile Overlay */}
      <AnimatePresence>
        {isSidebarOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsSidebarOpen(false)}
            className="fixed inset-0 bg-slate-900/20 backdrop-blur-sm z-40 lg:hidden"
          />
        )}
      </AnimatePresence>
    </div>
  );
}
