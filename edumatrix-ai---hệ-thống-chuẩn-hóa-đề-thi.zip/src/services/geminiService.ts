import { GoogleGenAI } from "@google/genai";

export const MODELS = [
  { id: 'gemini-3-flash-preview', name: 'Gemini 3 Flash (Nhanh)' },
  { id: 'gemini-3.1-pro-preview', name: 'Gemini 3.1 Pro (Thông minh)' },
  { id: 'gemini-2.5-flash-preview', name: 'Gemini 2.5 Flash' }
];

export async function callGeminiAI(prompt: string, apiKey: string, modelId: string = MODELS[0].id): Promise<string | null> {
  if (!apiKey) return null;

  const ai = new GoogleGenAI({ apiKey });
  
  try {
    const response = await ai.models.generateContent({
      model: modelId,
      contents: prompt,
      config: {
        temperature: 0.7,
        maxOutputTokens: 4096,
      }
    });

    return response.text || null;
  } catch (error: any) {
    console.error("Gemini API Error:", error);
    // Fallback logic could be implemented here if needed, 
    // but the baseline suggests using the named parameter initialization.
    throw error;
  }
}

export const PROMPTS = {
  GENERATE_QUESTIONS: (topic: string, level: string, count: number) => `
    Hãy tạo ${count} câu hỏi trắc nghiệm cho chủ đề "${topic}" ở mức độ "${level}".
    Yêu cầu trả về định dạng JSON mảng các đối tượng:
    {
      "content": "Nội dung câu hỏi",
      "type": "multiple_choice",
      "options": ["A", "B", "C", "D"],
      "correctAnswer": "Đáp án đúng",
      "explanation": "Giải thích ngắn gọn"
    }
  `,
  GENERATE_MATRIX: (subject: string, topics: any[]) => `
    Dựa trên môn học "${subject}" và các chủ đề sau: ${JSON.stringify(topics)},
    hãy đề xuất một ma trận đề thi chuẩn (tổng 10 điểm, 40 câu).
    Trả về JSON cấu trúc ma trận.
  `
};
