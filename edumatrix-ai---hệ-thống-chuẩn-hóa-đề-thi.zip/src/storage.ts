import { AppData, CognitiveLevel, QuestionType } from "./types";

const STORAGE_KEY = 'edumatrix_data';

export const DEFAULT_DATA: AppData = {
  subjects: [
    {
      id: '1',
      name: 'Toán học 12',
      icon: 'Calculator',
      topics: [
        { id: 't1', name: 'Ứng dụng đạo hàm để khảo sát hàm số', periods: 15, outcomes: ['Biết tính đơn điệu', 'Tìm cực trị'] },
        { id: 't2', name: 'Hàm số lũy thừa, mũ và logarit', periods: 12, outcomes: ['Tính toán logarit', 'Giải phương trình mũ'] }
      ]
    },
    {
      id: '2',
      name: 'Ngữ văn 12',
      icon: 'BookOpen',
      topics: [
        { id: 't3', name: 'Văn học hiện đại Việt Nam', periods: 20, outcomes: ['Phân tích tác phẩm', 'Nắm vững phong cách tác giả'] }
      ]
    }
  ],
  questions: [
    {
      id: 'q1',
      subjectId: '1',
      topicId: 't1',
      content: 'Cho hàm số y = f(x) có đạo hàm f\'(x) = x(x-1)^2. Số điểm cực trị của hàm số là:',
      type: QuestionType.MULTIPLE_CHOICE,
      level: CognitiveLevel.UNDERSTAND,
      options: ['0', '1', '2', '3'],
      correctAnswer: '1',
      explanation: 'f\'(x) đổi dấu khi qua x=0, không đổi dấu khi qua x=1.'
    },
    {
      id: 'q2',
      subjectId: '1',
      topicId: 't2',
      content: 'Tập nghiệm của phương trình log2(x-1) = 3 là:',
      type: QuestionType.MULTIPLE_CHOICE,
      level: CognitiveLevel.RECOGNIZE,
      options: ['{7}', '{8}', '{9}', '{10}'],
      correctAnswer: '{9}',
      explanation: 'x-1 = 2^3 = 8 => x = 9.'
    }
  ],
  matrices: [
    {
      id: 'm1',
      subjectId: '1',
      name: 'Ma trận Kiểm tra Giữa kỳ I - Toán 12',
      cells: [
        { topicId: 't1', level: CognitiveLevel.RECOGNIZE, type: QuestionType.MULTIPLE_CHOICE, count: 5 },
        { topicId: 't1', level: CognitiveLevel.UNDERSTAND, type: QuestionType.MULTIPLE_CHOICE, count: 5 },
        { topicId: 't2', level: CognitiveLevel.RECOGNIZE, type: QuestionType.MULTIPLE_CHOICE, count: 3 }
      ],
      totalScore: 10,
      duration: 90
    }
  ],
  exams: [
    {
      id: 'e1',
      matrixId: 'm1',
      name: 'Đề thi thử Tốt nghiệp THPT 2024 - Mã đề 101',
      questions: [],
      createdAt: new Date().toISOString()
    }
  ],
  settings: {
    theme: 'light',
    apiKey: '',
    model: 'gemini-3-flash-preview'
  }
};

export const storage = {
  get: (): AppData => {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : DEFAULT_DATA;
  },
  set: (data: AppData) => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  },
  reset: () => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_DATA));
  }
};
