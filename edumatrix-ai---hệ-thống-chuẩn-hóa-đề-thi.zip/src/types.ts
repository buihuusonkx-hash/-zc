export enum QuestionType {
  MULTIPLE_CHOICE = 'multiple_choice',
  TRUE_FALSE = 'true_false',
  SHORT_ANSWER = 'short_answer'
}

export enum CognitiveLevel {
  RECOGNIZE = 'recognize', // Nhận biết
  UNDERSTAND = 'understand', // Thông hiểu
  APPLY = 'apply', // Vận dụng
  HIGH_APPLY = 'high_apply' // Vận dụng cao
}

export interface Topic {
  id: string;
  name: string;
  periods: number; // Số tiết
  outcomes: string[]; // Yêu cầu cần đạt
}

export interface Subject {
  id: string;
  name: string;
  icon: string;
  topics: Topic[];
}

export interface Question {
  id: string;
  subjectId: string;
  topicId: string;
  content: string;
  type: QuestionType;
  level: CognitiveLevel;
  options?: string[];
  correctAnswer: string | boolean;
  explanation?: string;
}

export interface MatrixCell {
  topicId: string;
  level: CognitiveLevel;
  type: QuestionType;
  count: number;
}

export interface ExamMatrix {
  id: string;
  subjectId: string;
  name: string;
  cells: MatrixCell[];
  totalScore: number;
  duration: number; // minutes
}

export interface Exam {
  id: string;
  matrixId: string;
  name: string;
  questions: Question[];
  createdAt: string;
}

export interface AppData {
  subjects: Subject[];
  questions: Question[];
  matrices: ExamMatrix[];
  exams: Exam[];
  settings: {
    theme: 'light' | 'dark';
    apiKey: string;
    model: string;
  };
}
